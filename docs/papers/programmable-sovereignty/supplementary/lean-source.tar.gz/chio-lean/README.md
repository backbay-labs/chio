# Chio Lean Substrate (parent-paper companion)

This tarball contains the Lean 4 sources that mechanize the four theorems
named in the parent paper "Programmable Sovereignty: Lean-Attestable
Constitutions Over Capability-Bounded Federated Receipts".

## Layout

```
chio-lean/
  lean-toolchain         Pinned Lean release (read by elan)
  lakefile.lean          Lake build definition
  lake-manifest.json     Lake dependency manifest
  Chio.lean              Root module (re-exports every proof module)
  Chio/                  Source subtree (Core, Capability, Proofs, Spec, Treaty)
```

The four parent-paper theorems live in `Chio/Treaty/Intersection.lean`:

1. `treaty_admission_iff_predicate_intersection`
2. `treaty_admission_stable_under_ladder_floor`
3. `amendment_admissible_iff_backward_refinement`
4. `amendment_without_refinement_rejected`

## Building

Install `elan` (the Lean version manager) if it is not already present:

```
curl https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh -sSf | sh
```

The `lean-toolchain` file pins the exact Lean release; elan installs it on
first invocation. Then, from the tarball root:

```
cd chio-lean
lake build
```

A cold cache takes roughly 3-5 minutes. The build succeeds without warnings
and without any `sorry` or project-local `axiom` declarations.

## Verifying the four theorems

To inspect the axiom set each theorem depends on, append the four
`#print axioms` lines below to `Chio/Treaty/Intersection.lean` and re-run
`lake env lean Chio/Treaty/Intersection.lean`:

```
#print axioms treaty_admission_iff_predicate_intersection
#print axioms treaty_admission_stable_under_ladder_floor
#print axioms amendment_admissible_iff_backward_refinement
#print axioms amendment_without_refinement_rejected
```

The reported axiom set is recorded in `proof-manifest.toml` and
`theorem-inventory.json` shipped alongside this tarball. Only standard
Lean kernel axioms appear; no project-specific axioms are introduced.
