# Chio Lean artifact

Paper: Proof-Carrying Bilateral Admission for Cross-Organization Agent Tool Calls
Snapshot date: 2026-07-25

Build from this directory:

```sh
lake build
```

The paper claims only bounded model theorems. It does not claim that this
project verifies the production Rust implementation.

To reproduce the recorded axiom lists:

```lean
import Chio.Treaty.BridgeEquivalence
#print axioms Chio.Treaty.IntersectionSyntactic.treaty_admission_iff_predicate_intersection
#print axioms Chio.Treaty.IntersectionSyntactic.treaty_admission_stable_under_ladder_floor
#print axioms Chio.Treaty.PredicateLang.refinesOnConstitution_iff
#print axioms Chio.Treaty.PredicateLang.bridge_decidable_soundness
#print axioms Chio.Treaty.BridgeEquivalence.Legacy.treaty_admission_agrees
#print axioms Chio.Treaty.BridgeEquivalence.Legacy.bounded_amendment_sound
```
