import Chio.Treaty.ReceiptPredicate
