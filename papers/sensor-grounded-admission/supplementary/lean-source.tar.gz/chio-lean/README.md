# Chio Lean Substrate (sensor-grounded-admission companion)

This tarball contains the Lean 4 sources that mechanize the four theorems
named in the paper "Sensor-Grounded Admission: Polity Receipts with
Attested Substrate State". The tree also retains the wider Chio Lean
substrate (Core, Capability, Proofs, Spec, Treaty) on which the four
theorems depend; the sensor-grounded module imports
`Chio.Treaty.PredicateLang` and `Chio.Treaty.Intersection`, both of
which appear in the same tree.

## Layout

```
chio-lean/
  lean-toolchain         Pinned Lean release (read by elan)
  lakefile.lean          Lake build definition
  lake-manifest.json     Lake dependency manifest
  Chio.lean              Root module (re-exports every proof module,
                         including Chio.Treaty.SensorGroundedAdmission)
  Chio/                  Source subtree (Core, Capability, Proofs, Spec, Treaty)
  Chio/Treaty/SensorGroundedAdmission.lean
                         The four sensor-grounded theorems.
```

The four sensor-grounded theorems live in
`Chio/Treaty/SensorGroundedAdmission.lean`, under the
`Chio.Treaty.SensorAttestation` namespace:

1. `admission_predicate_separates_healthy_and_degraded_witnesses`
2. `partition_contingency_mode_iff_degraded_subset`
3. `healthy_attestation_required_for_destructive_admission`
4. `degraded_sensor_admission_requires_re_attestation`

## Building

Install `elan` (the Lean version manager) if it is not already present:

```
curl https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh -sSf | sh
```

The `lean-toolchain` file pins the exact Lean release; elan installs it on
first invocation. Then, from the tarball root:

```
cd chio-lean
lake build
```

A cold cache takes roughly 3-5 minutes. The build succeeds without
warnings and without any `sorry` or project-local `axiom` declarations.
The sensor-grounded module builds at job 10 of 24 in the dependency graph.

## Verifying the four theorems

To inspect the axiom set each theorem depends on, append the four
`#print axioms` lines below to
`Chio/Treaty/SensorGroundedAdmission.lean` and re-run
`lake env lean Chio/Treaty/SensorGroundedAdmission.lean`:

```
#print axioms Chio.Treaty.SensorAttestation.admission_predicate_separates_healthy_and_degraded_witnesses
#print axioms Chio.Treaty.SensorAttestation.partition_contingency_mode_iff_degraded_subset
#print axioms Chio.Treaty.SensorAttestation.healthy_attestation_required_for_destructive_admission
#print axioms Chio.Treaty.SensorAttestation.degraded_sensor_admission_requires_re_attestation
```

The reported axiom set is recorded in `proof-manifest.toml` and
`theorem-inventory.json` shipped alongside this tarball. Only standard
Lean kernel axioms appear (`propext`, `Classical.choice`, `Quot.sound`);
no project-specific axioms are introduced.
